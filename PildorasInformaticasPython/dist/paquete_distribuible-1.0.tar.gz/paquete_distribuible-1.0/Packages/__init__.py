# PAQUETES

"""
- Para que una carpeta funcione como paquete es necesario crear un archivo
que se llame __init__.py

- se debe crear la carpeta __pycache__
"""

