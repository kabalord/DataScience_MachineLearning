from setuptools import setup

setup(
    name="paquete_distribuible",
    version="1.0",
    description="explicar para que sirve el paquete",
    author="walter roa",
    author_email="wroaserrano@gmail.com",
    url="walroa.com",
    packages=["Packages", "Packages"]
)

